# WALLETIX

WALLETIX is a personal finance tracker with a static HTML frontend and a Node.js/Express backend.

## Project layout

```text
WALLETIX/
├── Backend/
│   ├── package.json
│   ├── package-lock.json
│   └── server.js
├── Frontend/
│   └── index.html
├── .gitignore
└── README.md
```

## Requirements

- Node.js 22.13 or newer (the backend uses the built-in `node:sqlite` module)
- npm

## Run the backend

```powershell
cd Backend
npm install
npm start
```

The API starts at `http://localhost:5000`.

## Run the frontend

Open `Frontend/index.html` in a browser. The backend connection status will show whether the API is available. The frontend also supports local mode when the backend is offline.

## API routes

- `GET /` — backend status
- `GET /transactions` — list transactions
- `POST /transactions` — add a transaction with JSON such as:

```json
{
  "description": "Groceries",
  "amount": 42.5,
  "type": "expense"
}
```

The backend creates `Backend/walletix.db` automatically on first run. Database files and installed dependencies are excluded from Git; each developer gets a local database.

## Upload to GitHub

Create an empty repository on GitHub, then run these commands from this folder:

```powershell
git add .
git commit -m "Prepare WALLETIX project for GitHub"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your GitHub repository URL. Review the files shown by `git status` before pushing.
